// import React from 'react'

// const Home=()=>{
//     return(
//         <>
//             <h1>Welcome To Our Banking System</h1>

//         </>
//     )
// }

import React from 'react'
<link rel="stylesheet" href="index.css" />


const Home = () => {
    return (
        <>
            <div className="bgimage">
                <div className="heada">
                    <h1>Welcome To Our Banking System</h1>
                </div>
        </div>

        </>
    )
}

export default Home